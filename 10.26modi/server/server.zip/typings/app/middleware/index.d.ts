// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportOauth = require('../../../app/middleware/oauth');

declare module 'egg' {
  interface IMiddleware {
    oauth: typeof ExportOauth;
  }
}
